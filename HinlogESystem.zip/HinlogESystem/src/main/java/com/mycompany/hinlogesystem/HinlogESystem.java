package com.mycompany.hinlogesystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class HinlogESystem {
    
    static Connection con;
    static Statement st;
    static ResultSet rs;
    
    static String db;
    static String uname;
    static String pswd;

    public static void main(String[] args) {     
        Login login = new Login();
        login.setVisible(true);
        login.setLocationRelativeTo(null);
    }  
    
    public static void DBConnect(){   
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + db + "?zeroDateTimeBehavior=CONVERT_TO_NULL", uname, pswd);
            st = con.createStatement();
            System.out.println("Connected");
        } catch (Exception ex){
            System.out.println("Failed to Connect" + ex);
        }      
    }
    
    
    public static void createData(){
    uname = "root";
    pswd = "@Lemeosa1221";
    
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?zeroDateTimeBehavior=CONVERT_TO_NULL", uname, pswd);
        st = con.createStatement();
        String createData = "CREATE DATABASE IF NOT EXISTS `" + db + "`";
        st.executeUpdate(createData);
        
        String useDatabase = "USE " + db;
        st.executeUpdate(useDatabase);
        System.out.println("Switched to database.");
        
        //create Students Table
        String createStudentsTable = "CREATE TABLE IF NOT EXISTS students (" +
        "studId INT PRIMARY KEY AUTO_INCREMENT," +
        "studName TEXT," +
        "studAddress TEXT, " +
        "studContact TEXT, " +
        "studCourse TEXT, " +
        "studGender TEXT, " +
        "studYrlvl TEXT" +
        ") AUTO_INCREMENT = 1001";
        st.executeUpdate(createStudentsTable);
        System.out.println("Students table created successfully or already exists.");
    
        // Create Subjects table
        String createSubjectsTable = "CREATE TABLE IF NOT EXISTS subjects (" +
            "subId INT PRIMARY KEY AUTO_INCREMENT, " +
            "subUnits INT, " +
            "subCode TEXT, " +
            "subDescription TEXT, " +
            "subSchedule TEXT" +
            ") AUTO_INCREMENT = 2001";
        st.executeUpdate(createSubjectsTable);
        System.out.println("Subjects table created successfully or already exists.");
    
        // Create Teachers table
        String createTeachersTable = "CREATE TABLE IF NOT EXISTS teachers (" +
            "teachId INT PRIMARY KEY AUTO_INCREMENT, " +
            "teachName TEXT, " +
            "teachAddress TEXT, " +
            "teachContact TEXT, " +
            "teachEmail TEXT, " +
            "teachDepartment TEXT" +
            ") AUTO_INCREMENT = 3001";
        st.executeUpdate(createTeachersTable);
        System.out.println("Teachers table created successfully or already exists.");
    
        // Create TransactionCharges table
        String createTransactionChargesTable = "CREATE TABLE IF NOT EXISTS TransactionCharges (" +
            "TransID INT PRIMARY KEY AUTO_INCREMENT, " +
            "Department TEXT, " +
            "SubjUnits DECIMAL(10,2), " +
            "Insurance DECIMAL(10,2), " +
            "Computer DECIMAL(10,2), " +
            "Laboratory DECIMAL(10,2), " +
            "Cultural DECIMAL(10,2), " +
            "`Library` DECIMAL(10,2), " +
            "Facility DECIMAL(10,2)" +
            ")";
        st.executeUpdate(createTransactionChargesTable);
        System.out.println("TransactionCharges table created successfully or already exists.");
        
        // Create Enroll table (depends on Students and Subjects)
        String createEnrollTable = "CREATE TABLE IF NOT EXISTS Enroll (" +
            "eid INT PRIMARY KEY AUTO_INCREMENT, " +
            "studid INT, " +
            "subjid INT," +
            "FOREIGN KEY (studid) REFERENCES students(studId), " +
            "FOREIGN KEY (subjid) REFERENCES subjects(subId)," +
            "UNIQUE (studid, subjid)" +
            ")";
        st.executeUpdate(createEnrollTable);
        System.out.println("Enroll table created successfully or already exists.");
        
        // Create Assign table (depends on Teachers and Subjects)
        String createAssignTable = "CREATE TABLE IF NOT EXISTS Assign (" +
            "subid INT UNIQUE," +
            "tid INT," +
            "FOREIGN KEY (subid) REFERENCES subjects(subId), " +
            "FOREIGN KEY (tid) REFERENCES teachers(teachId)" +
            ")";
        st.executeUpdate(createAssignTable);
        System.out.println("Assign table created successfully or already exists.");
        
        // Create Grades table (depends on Enroll)
        String createGradesTable = "CREATE TABLE IF NOT EXISTS Grades (" +
            "GradeID INT PRIMARY KEY AUTO_INCREMENT, " +
            "eid INT UNIQUE, " +
            "Prelim TEXT, " +
            "Midterm TEXT, " +
            "Prefinal TEXT, " +
            "Final TEXT, " +
            "FOREIGN KEY (eid) REFERENCES enroll(eid)" +
            ")";
        st.executeUpdate(createGradesTable);
        System.out.println("Grades table created successfully or already exists.");
        
        // Create Invoice table (depends on Students and TransactionCharges)
        String createInvoiceTable = "CREATE TABLE IF NOT EXISTS Invoice (" +
            "Invoicenum INT PRIMARY KEY AUTO_INCREMENT, " +
            "studid INT, " +
            "TransID INT" +
            ")";
        st.executeUpdate(createInvoiceTable);
        System.out.println("Invoice table created successfully or already exists.");
        
        System.out.println("All database structures created successfully!");
        
        JOptionPane.showMessageDialog(null,"Database Created: " + db + "\n or \n Database already Exists","New Database", JOptionPane.INFORMATION_MESSAGE);
            
    } catch (Exception ex){
        System.out.println("Failed to Create Database: " + ex);
    }
    
    DBConnect();
    }
    
    public static void userLogin(String user, String pass){
       
        uname = user;
        pswd = pass;
       
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/?zeroDateTimeBehavior=CONVERT_TO_NULL", uname, pswd);
            st = con.createStatement();
            System.out.println("Connected");
        } catch (Exception ex){
            System.out.println("Failed to Connect" + ex);
        }
    }
}
