/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hinlogesystem;

public class Students extends HinlogESystem{
    int studId;
    String studName, studAddress, studContact, studCourse, studGender, studYrLvl;
    
    Students(){
        connectDB();
    }   
    
    public void connectDB(){     
        DBConnect();
        StudentsForm form = new StudentsForm();
    }
    
    public void saveRecord(String name, String address, String contact, String course, String gender, String yrLvl){

        String query = "insert into students (studName, studAddress, studContact, studCourse, studGender, studYrLvl) values('" + name + "','" + address + "','" + contact + "','" + course + "','" + gender + "','" + yrLvl + "');";
        
        try {
            st.executeUpdate(query);
            System.out.println("Insert Success");
        } catch (Exception ex){
            System.out.println("Failed to Insert: " + ex);
        }
    }
    
    public void deleteRecord(int id){
        String query = "delete from students where studId = " + id;
        
        try {
            st.executeUpdate(query);
            System.out.println("Delete Success");
        } catch (Exception ex){
            System.out.println("Failed to Delete: " + ex);
        }
        
        String query2 = "DELETE FROM Enroll WHERE studid = " + id;
        try {
            st.executeUpdate(query2);
            System.out.println("Drop Success");
        } catch (Exception ex){
            System.out.println("Failed to Drop: " + ex);
        }
    }
    
    public void updateRecord(int id, String name, String address, String contact, String course, String gender, String yrLvl){
        String query = "UPDATE students SET " +
               "studName = '" + name + "', " +
               "studAddress = '" + address + "', " +
               "studContact = '" + contact + "', " +
               "studCourse = '" + course + "', " +
               "studGender = '" + gender + "', " +
               "studYrLvl = '" + yrLvl + "' " +
               "WHERE studId = " + id;
        
        try {
            st.executeUpdate(query);
            System.out.println("Update Success");
        } catch (Exception ex){
            System.out.println("Failed to Update: " + ex);
        }
    }
}
