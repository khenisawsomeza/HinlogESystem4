/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.esystem;

/**
 *
 * @author kbhinlog
 */
public class Students extends Esystem{
    int studentID;
    String name, address, contact, gender, yearlvl;
    
    Students(){
        connectDB();
    }
    
    public void connectDB(){
        DBConnect();
    }
    
    public void saveRecord(int id, String name, String address, String contact, String gender, String yrLvl){
        String query = "insert into 1stSem_Sy2025_2026.students values(" + id + ",'" + name + "','" + address + "','" + contact + "','" + gender + "','" + yrLvl + "');";
        
        
        try {
            st.executeUpdate(query);
            System.out.println("Insert Success");
        } catch (Exception ex){
            System.out.println("Failed to Insert: " + ex);
        }
    }
    public void deleteRecord(int id){
        String query = "";
        
        try {
            st.executeUpdate(query);
            System.out.println("Delete Success");
        } catch (Exception ex){
            System.out.println("Failed to Delete: " + ex);
        }
    }
    public void updateRecord(){
        System.out.println("Update Clicked");
    }
}
