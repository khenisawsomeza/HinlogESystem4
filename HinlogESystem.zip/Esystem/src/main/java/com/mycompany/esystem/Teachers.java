/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.esystem;

/**
 *
 * @author kbhinlog
 */
public class Teachers {
    int tID;
    String tName, tAdd, tContact, tEmail, tDept;
    
    public void saveRecord(){
        System.out.println("Save Clicked");
    }
    public void deleteRecord(){
        System.out.println("Delete Clicked");
    }
    public void updateRecord(){
        System.out.println("Update Clicked");
    }
}
